<?php die('Unauthorized access.'); ?>a:40:{s:2:"id";s:1:"1";s:4:"type";s:8:"document";s:11:"contentType";s:9:"text/html";s:9:"pagetitle";s:4:"Home";s:9:"longtitle";s:24:"Welcome to Learning MODx";s:11:"description";s:27:"My Personal Site using MODx";s:5:"alias";s:5:"index";s:15:"link_attributes";s:0:"";s:9:"published";s:1:"1";s:8:"pub_date";s:1:"0";s:10:"unpub_date";s:1:"0";s:6:"parent";s:1:"0";s:8:"isfolder";s:1:"0";s:9:"introtext";s:31:"The welcome page to my visitors";s:7:"content";s:221:"<h3>Welcome to My Personal Site&nbsp;</h3>
<p><img src="assets/images/Fractal_Broccoli.jpg" alt="" width="448" height="336" /></p>
<p> <strong>enjoy the stay :)</strong></p>
<p>
<br /><a href="[~57~]">Register</a></p>";s:8:"richtext";s:1:"1";s:8:"template";s:1:"5";s:9:"menuindex";s:1:"1";s:10:"searchable";s:1:"1";s:9:"cacheable";s:1:"1";s:9:"createdby";s:1:"1";s:9:"createdon";s:10:"1144904400";s:8:"editedby";s:1:"1";s:8:"editedon";s:10:"1282245848";s:7:"deleted";s:1:"0";s:9:"deletedon";s:1:"0";s:9:"deletedby";s:1:"0";s:11:"publishedon";s:1:"0";s:11:"publishedby";s:1:"0";s:9:"menutitle";s:4:"Home";s:7:"donthit";s:1:"0";s:11:"haskeywords";s:1:"0";s:11:"hasmetatags";s:1:"0";s:10:"privateweb";s:1:"0";s:10:"privatemgr";s:1:"0";s:13:"content_dispo";s:1:"0";s:8:"hidemenu";s:1:"0";s:6:"blogRT";a:5:{i:0;s:6:"blogRT";i:1;s:0:"";i:2;s:8:"richtext";i:3;s:27:"&w=100%&h=300px&edt=TinyMCE";i:4;s:8:"richtext";}s:17:"__MODxSJScripts__";a:5:{i:1;s:90:"	<link rel="stylesheet" type="text/css" href="assets/plugins/codeprettify/prettify.css" />";i:2;s:97:"	<link rel="stylesheet" type="text/css" href="assets/plugins/codeprettify/prettify-custom.css" />";i:3;s:89:"	<script type="text/javascript" src="manager/media/script/mootools/mootools.js"></script>";i:4;s:87:"	<script type="text/javascript" src="assets/plugins/codeprettify/prettify.js"></script>";i:5;s:81:"<script type="text/javascript">window.addEvent("domready", prettyPrint);</script>";}s:17:"__MODxDocGroups__";s:0:"";}<!--__MODxCacheSpliter__--><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd"> <html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en">
 <head>
  <base href="http://localhost/learningMODx/"></base>
  <title>Learning MODx</title>
  <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
  <link rel="stylesheet" type="text/css" href="assets/templates/learningMODx/style.css" />
 </head>
 <body>
  <div id="banner">
   <h1>Learning MODx</h1>
  </div>
  <div id="wrapper">
   <div id="container">
    <div id="content">
     <div id="col-1">
    <div id="menu">
        [!Wayfinder?startId=`0` &level=`2` &outerClass=`outer` &innerClass='inner' &lastClass=`last` &firstClass=`first` &hereClass=`active`!]
      </div>

      <h1>Home</h1>
      <br/>
      <h3>Welcome to My Personal Site&nbsp;</h3>
<p><img src="assets/images/Fractal_Broccoli.jpg" alt="" width="448" height="336" /></p>
<p> <strong>enjoy the stay :)</strong></p>
<p>
<br /><a href="[~57~]">Register</a></p>
     </div>
     <div id="col-2" >
    <div> [!Fortunes!] </div>
    <div > [!Personalize?&yesChunk=`profilelink`!]
                                     [!WebLogin!]  </div>

       <div>
        [!Ditto? &parents=`47` &tpl=`dittofrontpage`!]
       </div>
       <div> 
       [!DittoCal?calSource=`59` !]
       </div>
      </div>
    </div>
   </div>
   <div class="clearing"> </div>
  </div> <!-- end of wrapper div -->
  <div id="footer">It is fun and exciting to build websites with
                                               MODx</div></body>
</html>
