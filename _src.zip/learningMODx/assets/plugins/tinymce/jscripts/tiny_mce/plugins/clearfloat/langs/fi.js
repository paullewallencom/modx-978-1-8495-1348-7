// UK lang variables

tinyMCE.addI18n('fi.clearfloat', {
	button_desc : 'Flow below floated elements'
});
