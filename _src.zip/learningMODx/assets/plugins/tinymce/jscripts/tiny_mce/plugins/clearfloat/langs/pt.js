// UK lang variables

tinyMCE.addI18n('pt.clearfloat', {
	button_desc : 'Flow below floated elements'
});
