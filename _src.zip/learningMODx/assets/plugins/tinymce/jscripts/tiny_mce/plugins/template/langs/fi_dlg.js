tinyMCE.addI18n('fi.template_dlg',{
title:"Sivupohjat",
label:"Sivupohja",
desc_label:"Kuvaus",
desc:"Lis\u00E4\u00E4 esim\u00E4\u00E4ritetty\u00E4 sivupohjasis\u00E4lt\u00F6\u00E4",
select:"Valitse sivupohja",
preview:"Esikatselu",
warning:"Varoitus: Sivupohjan p\u00E4ivitt\u00E4minen toisella saattaa aiheuttaa tiedon menetyksen.",
mdate_format:"%d.%m.%Y %H:%M:%S",
cdate_format:"%d.%m.%Y %H:%M:%S",
months_long:"Tammikuu,Helmikuu,Maaliskuu,Huhtikuu,Toukokuu,Kes\u00E4kuu,Hein\u00E4kuu,Elokuu,Syyskuu,Lokakuu,Marraskuu,Joulukuu",
months_short:"Tammi,Helmi,Maalis,Huhti,Touko,Kes\u00E4,Hein\u00E4,Elo,Syys,Loka,Marras,Joulu",
day_long:"sunnuntai,maanantai,tiistai,keskiviikko,torstai,perjantai,lauantai,sunnuntai",
day_short:"su,ma,ti,ke,to,pe,la,su"
});