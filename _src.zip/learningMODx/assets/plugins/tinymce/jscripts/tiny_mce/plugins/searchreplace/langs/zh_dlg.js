tinyMCE.addI18n('zh.searchreplace_dlg',{
searchnext_desc:"\u518D\u5BFB\u627E\u4E00\u6B21",
notfound:"\u672A\u627E\u5230\u5BFB\u627E\u9805\u3002 ",
search_title:"\u5BFB\u627E",
replace_title:"\u5BFB\u627E/\u53D6\u4EE3",
allreplaced:"\u66F4\u65B0\u5B8C\u6210\u3002 ",
findwhat:"\u5BFB\u627E\u5167\u5BB9",
replacewith:"\u53D6\u4EE3\u6210",
direction:"\u5BFB\u627E\u65B9\u5411",
up:"\u5F80\u4E0A",
down:"\u5F80\u4E0B",
mcase:"\u533A\u5206\u5927\u5C0F\u5BEB",
findnext:"\u4E0B\u4E00\u4E2A",
replace:"\u53D6\u4EE3",
replaceall:"\u5168\u90E8\u53D6\u4EE3"
});