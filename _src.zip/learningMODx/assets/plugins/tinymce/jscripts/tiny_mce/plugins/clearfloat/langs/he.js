// UK lang variables

tinyMCE.addI18n('he.clearfloat', {
	button_desc : 'Flow below floated elements'
});
