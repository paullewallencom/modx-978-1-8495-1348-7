// UK lang variables

tinyMCE.addI18n('fr.clearfloat', {
	button_desc : 'Flow below floated elements'
});
